package com.example.msregistryserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsRegistryServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
